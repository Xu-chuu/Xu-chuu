import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Registros1 extends JFrame {
    
    // Campos
    private final JTextField txtCarnet;
    private final JTextField txtNombre;
    private final JTextField txtGmail;
    private final JTextField txtTelefono;
    private final JTextField txtDireccion;
    private final JComboBox<String> cbCarrera;
    private final JButton btnGuardar;

    // Conexión
    private Connection conexion;

    public Registros1() {
        setTitle("Interfaz de Registro");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Etiquetas y campos
        JLabel lblCarnet = new JLabel("Número de carnet:");
        lblCarnet.setBounds(30, 30, 150, 25);
        add(lblCarnet);

        txtCarnet = new JTextField();
        txtCarnet.setBounds(180, 30, 150, 25);
        add(txtCarnet);

        JLabel lblNombre = new JLabel("Nombre completo:");
        lblNombre.setBounds(30, 70, 150, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(180, 70, 150, 25);
        add(txtNombre);

        JLabel lblGmail = new JLabel("Gmail:");
        lblGmail.setBounds(30, 110, 150, 25);
        add(lblGmail);

        txtGmail = new JTextField();
        txtGmail.setBounds(180, 110, 150, 25);
        add(txtGmail);

        JLabel lblTelefono = new JLabel("Número de teléfono:");
        lblTelefono.setBounds(30, 150, 150, 25);
        add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(180, 150, 150, 25);
        add(txtTelefono);

        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(30, 190, 150, 25);
        add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(180, 190, 150, 25);
        add(txtDireccion);

        JLabel lblCarrera = new JLabel("Carrera:");
        lblCarrera.setBounds(30, 230, 150, 25);
        add(lblCarrera);

        cbCarrera = new JComboBox<>(new String[]{"Ingeniería", "Medicina", "Derecho", "Arquitectura"});
        cbCarrera.setBounds(180, 230, 150, 25);
        add(cbCarrera);

        btnGuardar = new JButton("Continuar con el pago");
        btnGuardar.setBounds(100, 280, 200, 30);
        add(btnGuardar);

        // Acción botón
        btnGuardar.addActionListener((ActionEvent e) -> {
            guardarUsuario();
        });

        // Conexión a base de datos
        conectarBD();
    }

    private void conectarBD() {
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/registro_usuarios", "root", "");
            System.out.println("Conectado a la base de datos");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en la conexión: " + ex.getMessage());
        }
    }

    private void guardarUsuario() {
        try {
            String sql = "INSERT INTO usuarios (carnet, nombre_completo, gmail, telefono, direccion, carrera) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conexion.prepareStatement(sql);
            pst.setString(1, txtCarnet.getText());
            pst.setString(2, txtNombre.getText());
            pst.setString(3, txtGmail.getText());
            pst.setString(4, txtTelefono.getText());
            pst.setString(5, txtDireccion.getText());
            pst.setString(6, cbCarrera.getSelectedItem().toString());

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario registrado correctamente");

            // Limpiar campos
            txtCarnet.setText("");
            txtNombre.setText("");
            txtGmail.setText("");
            txtTelefono.setText("");
            txtDireccion.setText("");
            cbCarrera.setSelectedIndex(0);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        Registros1 r = new Registros1();
        r.setVisible(true);
    }
}