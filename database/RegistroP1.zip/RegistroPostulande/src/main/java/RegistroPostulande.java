import java.util.Scanner;
public class RegistroPostulande{
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String carnet, nombreCompleto, gmail, telefono, direccion, carrera;

        System.out.print("Número de carnet: ");
        carnet = sc.nextLine();

        System.out.print("Nombre completo: ");
        nombreCompleto = sc.nextLine();

        System.out.print("Gmail: ");
        gmail = sc.nextLine();

        System.out.print("Número de teléfono: ");
        telefono = sc.nextLine();

        System.out.print("Dirección: ");
        direccion = sc.nextLine();

        System.out.print("Carrera: ");
        carrera = sc.nextLine();

        System.out.println("\n--- Registro completado ---");
        System.out.println("Carnet: " + carnet);
        System.out.println("Nombre completo: " + nombreCompleto);
        System.out.println("Gmail: " + gmail);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Dirección: " + direccion);
        System.out.println("Carrera: " + carrera);

        System.out.println("\n✔ Continuar con el pago...");
    }
}