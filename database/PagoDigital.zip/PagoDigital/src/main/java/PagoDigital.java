import java.util.Scanner;

public class PagoDigital{
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            
            System.out.print("Número de carnet: ");
            String carnet = sc.nextLine();
            
            System.out.print("Nombre completo: ");
            String nombre = sc.nextLine();
            
            System.out.print("Correo Gmail: ");
            String gmail = sc.nextLine();
            
            System.out.println("\n--- Registro completado ---");
            System.out.println("Carnet: " + carnet);
            System.out.println("Nombre: " + nombre);
            System.out.println("Correo: " + gmail);
            
            System.out.println("\n=== Interfaz de Pago en Línea ===");
            System.out.println("1. Generar pago QR");
            System.out.println("2. Pago mediante transacción bancaria");
            System.out.print("Elige una opción: ");
            int opcion = sc.nextInt();
            
            if (opcion == 1) {
                System.out.println("\n*** Pago con QR ***");
                System.out.println("[QR generado aquí]");
                System.out.println("Instrucciones: Escanea el QR desde tu app bancaria y realiza el pago.");
                System.out.println("Una vez hecho el pago, espera la validación.");
            } else if (opcion == 2) {
                System.out.println("\n*** Pago con Transacción Bancaria ***");
                System.out.println("Banco: Banco Nacional Ejemplo");
                System.out.println("Número de cuenta: 1234567890");
                System.out.println("Instrucciones: Realiza la transferencia y envía el comprobante.");
                System.out.println("Una vez hecho el pago, espera la validación.");
            } else {
                System.out.println("Opción inválida.");
            }
        }
    }
}